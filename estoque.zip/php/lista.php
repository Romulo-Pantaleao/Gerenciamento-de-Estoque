<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciamento de Estoque</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div>
        <a class="sair" href="logoff.php">Sair</a> <!--ancorando um link no Botão de SAIR que redireciona para logoff.php-->
    </div>

<!--Tabela que Lista os Produtos Cadastrados-->
    <h2>Lista de Produtos</h2>

    <div>
        <form method="POST" action="pesquisar.php">
            <input type="text" name="pesquisar" placeholder="PESQUISAR" required> <!--id permite q seja referenciado em JavaScript-->
            <input type="submit" value="ENVIAR">
        </form>
    </div>



    <table id="productTable"> <!--id="productTable": Atribui um id único ao formulário, permitindo que ele seja manipulado por JS-->
        <thead> <!--Define um cabeçalho na tabela -->
            <tr> <!--Define uma linha na tabela
                th= Define uma célula de cabeçalho de coluna-->
                <th>ID</th>
                <th>Nome</th>
                <th>Quantidade</th>
                <th>Preço</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <!-- Define o corpo da tabela, onde as linhas de dados serão inseridas -->
        </tbody>
    </table>

    <script src="../js/script.js"></script> <!--Conexão com o javaScript-->

</body>

</html>