<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>Document</title>
</head>
<body>
    <div>
        <a class="sair" href="logoff.php">Sair</a> <!--ancorando um link no Botão de SAIR que redireciona para logoff.php-->
    </div>

<!--Tabela que Lista os Produtos Cadastrados-->
    <h2>Lista de Produtos</h2>

    <div>
        <form method="POST" action="">
            <input type="text" name="pesquisar" placeholder="PESQUISAR" required> <!--id permite q seja referenciado em JavaScript-->
            <input type="submit" value="ENVIAR">
        </form>
    </div>


<?php
include 'conexão.php';

// Certifique-se que $pesquisar está recebendo o valor do formulário
$pesquisar = $_POST['pesquisar'];

// Prepare a consulta e vincule o parâmetro corretamente
$stmt = $conn->prepare("SELECT id, nome_produto, quantidade, preco FROM produtos WHERE nome_produto REGEXP ?");
$stmt->bind_param("s", $pesquisar); // Remova as aspas e passe a variável diretamente


// Executar a consulta e verificar se houve sucesso
if ($stmt->execute()) {
    $result = $stmt->get_result();

    // Verificar se foram encontrados resultados
    if ($result->num_rows > 0) {
        echo "<table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Quantidade</th>
                    <th>Preço</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                <td>" . $row['id'] . "</td>
                <td>" . $row['nome_produto'] . "</td>
                <td>
                    <input type='number' id='quantidade-" . $row['id'] . "' value='" . $row['quantidade'] . "' min='0'>
                    <button class='quantity_data' data-id='updateQuantidade'" . $row['id'] . "' data-field='quantidade'>Atualizar</button>
                </td>
                <td>
                    <input type='number' step='0.01' id='preco-" . $row['id'] . "' value='" . $row['preco'] . "' min='0'>
                    <button class='quantity_data' data-id='updatePreco'" . $row['id'] . "' data-field='preco'>Atualizar</button>
                </td>
                <td>
                    <button class='deletar' data-id='deleteProduct'" . $row['id'] . "'>Deletar</button>
                </td>
            </tr>";
        }
        echo "</tbody>
        </table>";
    } else {
        echo "NENHUM PRODUTO ENCONTRADO.";
    }

    // Fechar o resultado
    $result->close();
} else {
    echo "Erro ao executar a consulta: " . $stmt->error;
}

// Fechar a declaração
$stmt->close();

// Fechar a conexão
$conn->close();
    ?>

<script src="../js/script.js"></script> <!--Conexão com o javaScript-->

</body>
</html>

